import { createRouter, createWebHistory } from '@ionic/vue-router';

import Main from '../views/main.vue';
// import Auth from '../views/Authorize/Auth.vue';

const routes = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/',
    component: Main,
    children: [
      {
        path: '',
        redirect: 'pages/home'
      },
      {
        path: '/home',
        component: () => import('@/views/Pages/Home.vue')
      },
      {
        path: '/category',
        component: () => import('@/views/Pages/Category.vue')
      },
      {
        path: '/account',
        component: () => import('@/views/Pages/Account.vue')
      }
    ]
  },
  {
    path: '/login',
    component: () => import('@/views/Authorize/Login.vue')
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
