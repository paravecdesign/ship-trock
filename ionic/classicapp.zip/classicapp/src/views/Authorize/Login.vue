<template>
  <ion-content>
    <div class="container">

  

    <ion-title>Login</ion-title>
   <ion-item>
    <ion-label position="floating">Email / Phone Number</ion-label>
    <ion-input></ion-input>
  </ion-item>
   <ion-item>
    <ion-label position="floating">Password</ion-label>
    <ion-input type="password"></ion-input>
  </ion-item>

  <div padding>
            <ion-button  size="large" type="submit" expand="block">Register</ion-button>
          </div>
    </div>
  </ion-content>
</template>

<script>
import { defineComponent } from 'vue';
import { IonContent, IonTitle } from '@ionic/vue';

export default defineComponent({
  name: 'Tab3Page',
  components: {IonContent, IonTitle }
});
</script>

<style>
ion-title{
  margin-top: 20vh;
  font-size: 35px;
  text-align: center;
}
.container{
  padding-right: 5%;
  padding-left: 5%;
}

ion-content{
  padding-left: 20%;
  justify-items: auto;
  justify-content: center;
}

ion-button{
  display: block;

}

ion-item{
  margin: 20px 0;
}
</style>